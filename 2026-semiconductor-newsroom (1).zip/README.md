# Silicon Brief — 2026 Semiconductor Industry Newsroom

A responsive, student-friendly newsroom explaining semiconductor industry developments in 2026. Built with plain HTML, CSS, and JavaScript; no build tools required.

## Files
- `index.html` — page content and source links
- `style.css` — responsive layout and visual styling
- `script.js` — light/dark theme toggle

## Run locally
Open `index.html` in a web browser.

## Deploy on GitHub and Vercel
1. Create a new GitHub repository named `2026-semiconductor-newsroom`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. In Vercel, choose **Add New → Project** and import that GitHub repository.
4. Keep the framework preset as **Other**. No build command is needed. Leave the output directory empty/default.
5. Click **Deploy**. Vercel will provide a public URL.
6. Whenever you push changes to the connected GitHub branch, Vercel can redeploy automatically.

## Research and original sources
The figures and claims in the page are linked to these original sources:
- WSTS, *Recent News Release / Spring 2026 forecast*: https://www.wsts.org/76/Recent-News-Release
- SEMI, *Global Semiconductor Equipment Sales Forecast to Reach a Record $229 Billion in 2028*: https://www.semi.org/en/semi-press-release/global-semiconductor-equipment-sales-forecast-to-reach-a-record-229-billion-dollars-in-2028-semi-reports
- TSMC third-quarter 2026 earnings release, filed with the SEC: https://www.sec.gov/Archives/edgar/data/1046179/000104617926000726/a3q26e_withguidancexfinal.htm
- NIST CHIPS resources: https://www.nist.gov/chips

## Research integrity notes
- WSTS market figures are forecasts, not final audited sales.
- TSMC Q3 revenue is a company-reported result from its official earnings release.
- SEMI's equipment sales figures are industry forecasts.
- This student explainer is educational and not investment advice.

## Suggested assignment checklist
- [ ] Read the original releases linked on the site.
- [ ] Verify the date, unit, and context of every statistic before presenting it.
- [ ] Replace or add stories after checking the newest official releases.
- [ ] Add your name and course details if required by your instructor.
- [ ] Publish on GitHub and deploy on Vercel.
