const toggle = document.getElementById("themeToggle");
toggle.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  toggle.textContent = document.body.classList.contains("dark") ? "☼" : "◐";
  toggle.setAttribute("aria-label", document.body.classList.contains("dark") ? "Switch to light theme" : "Switch to dark theme");
});
